/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateMyType = /* GraphQL */ `
  subscription OnCreateMyType {
    onCreateMyType {
      id
      title
      content
      price
      rating
    }
  }
`;
export const onUpdateMyType = /* GraphQL */ `
  subscription OnUpdateMyType {
    onUpdateMyType {
      id
      title
      content
      price
      rating
    }
  }
`;
export const onDeleteMyType = /* GraphQL */ `
  subscription OnDeleteMyType {
    onDeleteMyType {
      id
      title
      content
      price
      rating
    }
  }
`;
export const onCreateVodAsset = /* GraphQL */ `
  subscription OnCreateVodAsset {
    onCreateVodAsset {
      id
      title
      description
      video {
        id
      }
    }
  }
`;
export const onUpdateVodAsset = /* GraphQL */ `
  subscription OnUpdateVodAsset {
    onUpdateVodAsset {
      id
      title
      description
      video {
        id
      }
    }
  }
`;
export const onDeleteVodAsset = /* GraphQL */ `
  subscription OnDeleteVodAsset {
    onDeleteVodAsset {
      id
      title
      description
      video {
        id
      }
    }
  }
`;
export const onCreateVideoObject = /* GraphQL */ `
  subscription OnCreateVideoObject {
    onCreateVideoObject {
      id
    }
  }
`;
export const onUpdateVideoObject = /* GraphQL */ `
  subscription OnUpdateVideoObject {
    onUpdateVideoObject {
      id
    }
  }
`;
export const onDeleteVideoObject = /* GraphQL */ `
  subscription OnDeleteVideoObject {
    onDeleteVideoObject {
      id
    }
  }
`;
