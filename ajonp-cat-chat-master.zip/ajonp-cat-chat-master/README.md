# CodingCatDev on AWS Amplify Video

You can find the full lesson at https://codingcat.dev/lessons/aws-amplify-video

I have removed the Livestream so that no one accidentaly adds this expensive part to their instance.
If you find that you would like to have that part, you can either find the code in the lesson or the git history